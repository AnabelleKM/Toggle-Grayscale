function init(plugin)
  plugin:newCommand{
    id = "ToggleGrayscale",
    title = "Toggle Grayscale",
    group = "sprite_properties", -- Menu: Sprite > Toggle Grayscale
    onclick = function()
      local spr = app.activeSprite
      if not spr then
        app.alert("No active sprite.")
        return
      end

      local grayscaleLayerName = "__GrayscaleOverlay__"

      app.transaction("Toggle Grayscale Overlay", function()
        local foundLayer = nil

        for _, layer in ipairs(spr.layers) do
          if layer.name == grayscaleLayerName then
            foundLayer = layer
            break
          end
        end

        if foundLayer then
          -- Remove the overlay layer entirely
          spr:deleteLayer(foundLayer)
        else
          -- Create the grayscale overlay layer with BlendMode.COLOR
          local overlay = spr:newLayer()
          overlay.name = grayscaleLayerName
          overlay.blendMode = BlendMode.COLOR
          overlay.isVisible = true

          for _, cel in ipairs(spr.cels) do
            if cel.layer.isImage then
              local image = Image(spr.width, spr.height, spr.colorMode)
              image:clear(Color{ r=0, g=0, b=0, a=255 }) -- opaque black
              spr:newCel(overlay, cel.frameNumber, image, Point(0, 0))
            end
          end
        end
      end)

      app.refresh()
    end
  }
end

function exit(plugin)
  -- No cleanup needed for this plugin
end
